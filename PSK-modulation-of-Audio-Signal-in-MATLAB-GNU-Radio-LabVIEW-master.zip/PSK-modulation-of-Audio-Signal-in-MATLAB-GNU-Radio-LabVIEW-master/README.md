# BPSK-QPSK-modulation-of-Audio-Signal

### MATLAB Implementation:
![](bpskMAT.jpg)
![](qpskMAT.jpg)

### GNU Radio Implementation:
![](wsi1.png)

### LabVIEW Implementation:
![](lv1.png)
![](lv2.png)
      
