# SDR
Software Defined Radio (SDR). This Project is to  transmits  and receive audio file (.wav) using OFDM modulation in gnuradio. 
